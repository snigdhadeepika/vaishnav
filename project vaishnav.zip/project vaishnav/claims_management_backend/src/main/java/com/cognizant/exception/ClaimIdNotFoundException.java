package com.cognizant.exception;

public class ClaimIdNotFoundException extends Exception {
    public ClaimIdNotFoundException(String message) {
        super(message);
    }
}
