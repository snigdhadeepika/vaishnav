package com.cognizant.exception;

public class NewClaimExistException extends Exception {
    public NewClaimExistException(String message){
        super(message);
    }
}
