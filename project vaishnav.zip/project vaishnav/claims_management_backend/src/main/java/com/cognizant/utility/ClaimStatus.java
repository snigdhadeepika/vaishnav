package com.cognizant.utility;

public enum ClaimStatus {
    New, Approved, Rejected
}
