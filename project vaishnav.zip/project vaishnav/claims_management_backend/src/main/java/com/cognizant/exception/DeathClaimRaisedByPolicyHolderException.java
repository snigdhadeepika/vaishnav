package com.cognizant.exception;

public class DeathClaimRaisedByPolicyHolderException extends Exception{
    public DeathClaimRaisedByPolicyHolderException(String message){
        super(message);
    }
}
