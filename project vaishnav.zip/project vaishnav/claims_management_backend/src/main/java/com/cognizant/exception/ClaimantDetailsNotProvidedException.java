package com.cognizant.exception;

public class ClaimantDetailsNotProvidedException extends Exception{
    public ClaimantDetailsNotProvidedException(String message){
        super(message);
    }
}
