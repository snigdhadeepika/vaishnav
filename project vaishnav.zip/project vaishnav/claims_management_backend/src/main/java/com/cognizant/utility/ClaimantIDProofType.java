package com.cognizant.utility;

public enum ClaimantIDProofType {
    Passport, Aadhar, PAN, DrivingLicence
}