package com.cognizant.exception;

public class InvalidClaimTypeException extends Exception{
    public InvalidClaimTypeException(String message){
        super(message);
    }
}
