INSERT INTO Claim_Types(Claim_Types_Id, Type)
VALUES
    (1, 'Maturity Payout'),
    (2, 'Death'),
    (3, 'Premature Withdraw');

INSERT into Users
VALUES
    ('manager','manager123','manager',false),
    ('customer','customer123','customer',false);
