import { Claims } from './claims';

describe('Claims', () => {
  it('should create an instance', () => {
    expect(new Claims()).toBeTruthy();
  });
});
