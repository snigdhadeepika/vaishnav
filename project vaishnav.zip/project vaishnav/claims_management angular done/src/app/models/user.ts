export class User {
    userName: number;
    password: string;
    role: string;
    isAccountLocked: boolean;
}