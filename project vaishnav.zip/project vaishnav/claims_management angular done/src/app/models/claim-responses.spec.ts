import { ClaimResponses } from './claim-responses';

describe('ClaimResponses', () => {
  it('should create an instance', () => {
    expect(new ClaimResponses()).toBeTruthy();
  });
});
