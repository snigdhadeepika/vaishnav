export class ClaimResponses {
    claimResponsesId: number;
    responseDate: Date;
    responseDetails: string;
    claimId: number;
}
