export class ClaimTypes {
    claimTypesId: number;
    type: string;
}
