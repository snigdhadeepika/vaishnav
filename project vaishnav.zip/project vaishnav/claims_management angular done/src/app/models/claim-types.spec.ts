import { ClaimTypes } from './claim-types';

describe('ClaimTypes', () => {
  it('should create an instance', () => {
    expect(new ClaimTypes()).toBeTruthy();
  });
});
